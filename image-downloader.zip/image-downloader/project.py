from gettext import find
import re
import requests
from bs4 import BeautifulSoup as bs

baseURL = 'https://www.kayak.co.in'


# Scrape Hotels by city

hotels = []

soup = bs(requests.get(baseURL).text, features='html.parser')
getDivs = soup.find_all('div', {"class": "P_Ok-header-links"})

for div in getDivs:
    for link in div.find_all('a', href=True):
        getHotel = (link['href']).find('hotel')
        if (getHotel != -1):
            hotels.append(baseURL+link['href'])
# print(hotels[5])


# Scrape Specific Hotel by above city location
hotels_by_city = []

soup = bs(requests.get(hotels[5]).text, features='html.parser')
getHotels = soup.find_all('a', {'class': 'soom-name'})

for hotel in getHotels:
    hotels_by_city.append(baseURL + hotel['href'])
# print(hotels_by_city[5])


specific_Hotel = hotels_by_city[5]
print(specific_Hotel)

soup = bs(requests.get(specific_Hotel).content, "html.parser")

# Hotel Name Scrapped
hotelName = soup.find(class_='r9uX-hotel-name')
hotelName = hotelName.get_text()
print(hotelName)

# Hotel ID Scrapped
find = re.findall('[0-9]', specific_Hotel)
hotelId = ''.join(find)

print(hotelId)

# Image Scrapped
