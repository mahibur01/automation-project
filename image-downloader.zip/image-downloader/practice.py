import re
import json
import requests
# import pandas as pd

url = "https://www.fiba.basketball/euroleaguewomen/21-22/game/1310/MBA-Moscow-ZVVZ-USK-Praha#tab=shot_chart"
api_url = "https://livecache.sportresult.com/node/db/FIBASTATS_PROD/{event_id}_GAME_{rsc}_JSON.json?s=unknown&t=0"

html_doc = requests.get(url).text

event_id = re.search(r"setEventId\('(.*?)'\)", html_doc).group(1)
rsc = re.search(r"rsc: '(.*?)'", html_doc).group(1)
data = requests.get(api_url.format(event_id=event_id, rsc=rsc)).json()

# print full data:
# print(json.dumps(data, indent=4))

# print basic table:
df = pd.json_normalize(data["content"]["full"]["ScoreList"]).explode("Items")
df = pd.concat([df, df.pop("Items").apply(pd.Series)], axis=1)
print(df)