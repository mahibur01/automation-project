# Save Images by Soup


# soup = BeautifulSoup(getURL.text, 'html.parser')
# images = soup.find_all('img')
# # print(images)
# resolvedURLs = []
# for image in images: 
#     src = image.get('src')
#     resolvedURLs.append(requests.compat.urljoin(URL, src))
# for image in resolvedURLs: 
#     webs = requests.get(image)
#     open('images/' + image.split('/')[-1], 'wb').write(webs.content)
# print(getURL.status_code)



 