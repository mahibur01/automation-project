from cgitb import html
from email import parser
import requests
import re
from bs4 import BeautifulSoup as bs

# Website url
url_one = "https://www.kayak.co.in/?ispredir=true"

# Location url
url_two = "https://www.kayak.co.in/Kolkata-Hotels.44834.hotel.ksp"

# Hotel url
url_three = "https://www.kayak.co.in/Hyderabad-Hotels-Novotel-Hyderabad-Airport.156484.ksp"


# Go to website
stage_one = url_one


# Get status 200 (It's mean, url one visited)
getURL = requests.get(stage_one)

# Print Status
# print(getURL)

# if ok check 2nd url status
if getURL.status_code==200:
    stage_two = url_two

    # Get status 200 (It's mean, url two visited)
    getURL = requests.get(stage_two)

    # Print Status
    # print(getURL)

    if getURL.status_code==200:
        stage_three = url_three

        # Get status 200 (It's mean, url three visited)
        getURL = requests.get(stage_three)
    
        # Print Status    
        # print(getURL)


        if getURL.status_code==200:
 
            # Hotel ID Scrapped    
            find = re.findall('[0-9]', getURL)
            hotelId = ''.join(find)

            print(hotelId)


        if getURL.status_code==200:

            soup = bs(getURL.content, "html.parser") 
            
            # Hotel Name Scrapped
            hotelName = soup.find(class_='r9uX-hotel-name')    
            hotelName = hotelName.get_text() 
            print(hotelName)

            
else:
    print ('Unauthorized User')





# Save Images by Soup


# soup = BeautifulSoup(getURL.text, 'html.parser')
# images = soup.find_all('img')
# # print(images)
# resolvedURLs = []
# for image in images: 
#     src = image.get('src')
#     resolvedURLs.append(requests.compat.urljoin(URL, src))
# for image in resolvedURLs: 
#     webs = requests.get(image)
#     open('images/' + image.split('/')[-1], 'wb').write(webs.content)
# print(getURL.status_code)



 
